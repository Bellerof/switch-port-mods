These are the new mods that I'm using in my November 2023 Github post update.

The only missing mod is UltraCam by MaxLastBreath. Get it here: https://gamebanana.com/mods/480138