Credits:
theboy181

DISCLAIMER: This mod has my own personal values as I prefer a little more speed in the camera. 