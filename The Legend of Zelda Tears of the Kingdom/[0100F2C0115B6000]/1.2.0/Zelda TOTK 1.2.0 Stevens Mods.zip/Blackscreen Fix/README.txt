- Original Creator: MarethyuX

- Port to 1.0.0 by: StevenssND
